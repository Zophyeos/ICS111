import java.awt.Color;
import java.util.Random;

public class Milestone2 {

	static int posX=500;
	 static int posY=400;
	 static int directionX = 1;
	 static EZImage EnemyPict;
	 static EZImage HeroPict;
	 
	 public static void setup(){
		 EZ.initialize(1000,800); 
		
	 }
	 public static void Hero_Enemy_Collision(){
		 if(EnemyPict.isPointInElement(HeroPict.getXCenter(),HeroPict.getYCenter())) {
				EZ.removeEZElement(HeroPict);//remove hero
				EZ.addText(400, 400, "GAME OVER!",Color.black,40);
		 }
	 }
	 	
	
	 
	 public static void main(String[] args) {
			
		 	Random randomGenerator;
			randomGenerator= new Random();
		 
		 	setup();
			
			HeroPict= EZ.addImage("dude.png",randomGenerator.nextInt(1000), randomGenerator.nextInt(800) );
			
			EnemyPict= EZ.addImage("Danny.png",500,400);
			
			while(true){
			//makes the picture move
			EnemyPict.translateTo(posX, posY);
			posX=posX+directionX;
			
			
			//limits the enemy to move between 300 and 700 on the screen
			if (posX > 700 ) {
					directionX = -directionX;
				}
				if(posX<300){
					directionX = -directionX;
				}
				
			//movement of hero.my picture is just example	
			if(EZInteraction.isKeyDown('d')) { 
					HeroPict.translateBy(5f, 0f); 
			}else if(EZInteraction.isKeyDown('s')){
					HeroPict.translateBy(0f, 5f);
			}else if(EZInteraction.isKeyDown('a')){
					HeroPict.translateBy(-5f,0f);
			}else if(EZInteraction.isKeyDown('w')){
					HeroPict.translateBy(0f,-5f);
			}
				
			Hero_Enemy_Collision();
				EZ.refreshScreen();
				
			}//end while
	 }
			
		
}


