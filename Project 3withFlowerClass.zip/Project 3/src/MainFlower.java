import java.awt.Color;
import java.util.ArrayList;
import java.util.Random;

public class MainFlower {
	
	 public static void setup(){
		 EZ.initialize(1000,400); 
	 }
	
	public static void main(String [] args){
		setup();
		
		Random randomGenerator = new Random();
		ArrayList<flowerClass> flower = new ArrayList<flowerClass>();
		
		for(int i=0;i<10; i++){
			flower.add(new flowerClass("OpenFlower.png", randomGenerator.nextInt(1000), 400));
		}
		
		while(true){
			 for(int i=0;i<flower.size();i++){
				 flower.get(i).Move();
			 }
			 EZ.refreshScreen();
		}
		
	}
	
}
	