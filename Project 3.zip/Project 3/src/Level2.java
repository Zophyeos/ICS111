import java.awt.Color;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Scanner;

public class Level2 {
public static void main(String[] args) throws java.io.IOException {
		
		Scanner fileScanner = new Scanner(new FileReader("lvl2.txt"));
		FileWriter fw = new FileWriter("cleanlevel.txt");
		
		int width = fileScanner.nextInt();
		int height = fileScanner.nextInt();
		fw.write(width);
		fw.write(height);
		String inputText = fileScanner.nextLine();
		
		
	
		EZ.initialize(700,450);
//		EZ.setBackgroundColor(new Color(0, 0,0));
		EZImage back = EZ.addImage("lvl2Back.png",width*5,height*5);
		
		
		//tiles array
		ArrayList<EZImage> tiles = new ArrayList<EZImage>();
		
		EZImage player = EZ.addImage("chicken.png", 500, 200);
		
		//Group
		EZGroup root = EZ.addGroup();	
		
		//tiles 
		for(int line = 0; line < height; line++){
			
			inputText = fileScanner.nextLine();
			System.out.println(inputText);
			
			for (int i = 0; i < inputText.length(); i++){
				
				char ch = inputText.charAt(i);
		
				switch(ch){
					//Square tiles
				//Square tiles
				case 'L':
					tiles.add(EZ.addImage("GG1.png",i*32,line*32));
					break;		
				case 'M':
					tiles.add(EZ.addImage("GG2.png",i*32,line*32));
					break;
				case 'R':
					tiles.add(EZ.addImage("GG3.png",i*32,line*32));
					break;
				case 'D':
					tiles.add(EZ.addImage("GG5.png",i*32,line*32));
					break;
				case 'Y':
					tiles.add(EZ.addImage("GG6.png",i*32,line*32));
					break;	
				case 'F':
					tiles.add(EZ.addImage("GG4.png",i*32,line*32));
					break;
				//Angle tiles
				case 'H':
					tiles.add(EZ.addImage("HH1.png", i*32, line*32));
					break;		
				case 'J':
					tiles.add(EZ.addImage("HH4.png",i*32,line*32));
					break;	
				case 'K':
					tiles.add(EZ.addImage("HH2.png",i*32,line*32));
					break;		
				case 'Q':
					tiles.add(EZ.addImage("HH5.png",i*32,line*32));
					break;			
				default:
					// Do nothing
					break;							
				}
				
			} 
			

		}
		for(int i = 0; i < tiles.size(); i++){
			root.addElement(tiles.get(i));
		}
			
			root.addElement(player);
			
			
			// setup player speed
			float velocityX = 0f;
			float friction = 0.8f;
			
			// main loop
			while(true) {

				/* move player */
				if(EZInteraction.isKeyDown('a')) {
					velocityX -= 2f;
				}

				if(EZInteraction.isKeyDown('d')) {
					velocityX += 2f;
				}

				if(EZInteraction.isKeyDown('w')) {
					player.translateBy(0f, -4f);	
				}

				if(EZInteraction.isKeyDown('s')) {
					player.translateBy(0f, 4f);	
				}

				// apply friction
				velocityX *= friction;
				
				// move player
				player.translateBy(velocityX, 0);
				
				// NOTE: the other images don't move within the group
//				System.out.println(picture1.getXCenter());

				// keep the root group following the opposite of the character
				root.translateTo(-player.getXCenter() + 200f, 0);
				
				// update screen
				EZ.refreshScreen();

			}
	}
}
	
	

