import java.util.ArrayList;
import java.util.Random;

public class Main {

	 public static void setup(){
		 EZ.initialize(1000,1000); 
	 }
	 
	 public static void main(String[] args) {
		setup();
		 
		Random randomGenerator;
		randomGenerator= new Random();
		//ArrayList for Enemies
		ArrayList<Enemy1> Enemy= new ArrayList<Enemy1>();
		for(int i=0;i<10; i++){
			Enemy.add(new Enemy1("Danny.png",randomGenerator.nextInt(1000), randomGenerator.nextInt(600)));
		}
		
		
	 while(true){
		 for(int i=0;i<Enemy.size();i++){
			 Enemy.get(i).Move();
		 }
		 EZ.refreshScreen();
	 }
		 
	 }
}
