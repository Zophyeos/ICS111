import java.awt.Color;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Scanner;

public class Level1 {
	
	public static void main(String[] args) throws java.io.IOException {
		
		Scanner fileScanner = new Scanner(new FileReader("level.txt"));
		FileWriter fw = new FileWriter("cleanlevel.txt");
		
		int width = fileScanner.nextInt();
		int height = fileScanner.nextInt();
		fw.write(width);
		fw.write(height);
		String inputText = fileScanner.nextLine();
		
		
	
		EZ.initialize(700,450);
//		EZ.setBackgroundColor(new Color(0, 0,0));
		EZImage back = EZ.addImage("Back2.png",width*7,height);
		
		
		//tiles array
		ArrayList<EZImage> tiles = new ArrayList<EZImage>();
		
		EZImage player = EZ.addImage("chicken.png", 500, 200);
		
		//Group
		EZGroup root = EZ.addGroup();	
		
		//tiles 
		for(int line = 0; line < height; line++){
			
			inputText = fileScanner.nextLine();
			System.out.println(inputText);
			
			for (int i = 0; i < inputText.length(); i++){
				
				char ch = inputText.charAt(i);
		
				switch(ch){
				
				//Square tiles
				case 'L':
					tiles.add(EZ.addImage("LGrass.png",i*32,line*32));
					break;		
				case 'M':
					tiles.add(EZ.addImage("MGrass.png",i*32,line*32));
					break;
				case 'R':
					tiles.add(EZ.addImage("RGrass.png",i*32,line*32));
					break;
				case 'D':
					tiles.add(EZ.addImage("Mdirt.png",i*32,line*32));
					break;
				case 'Y':
					tiles.add(EZ.addImage("Rdirt.png",i*32,line*32));
					break;	
				case 'F':
					tiles.add(EZ.addImage("Ldirt.png",i*32,line*32));
					break;
				//Angle tiles
				case 'H':
					tiles.add(EZ.addImage("3.png", i*32, line*32));
					break;		
				case 'J':
					tiles.add(EZ.addImage("4.png",i*32,line*32));
					break;	
				case 'K':
					tiles.add(EZ.addImage("boto3.png",i*32,line*32));
					break;		
				case 'Q':
					tiles.add(EZ.addImage("boto2.png",i*32,line*32));
					break;		
				case 'W':
					tiles.add(EZ.addImage("boto5.png",i*32,line*32));
					break;		
				case 'E':
					tiles.add(EZ.addImage("boto6.png",i*32,line*32));
					break;		
				case 'T':
					tiles.add(EZ.addImage("boto9.png",i*32,line*32));
					break;		
				default:
					// Do nothing
					break;
					
							
				}
				
			} 
			

		}
		for(int i = 0; i < tiles.size(); i++){
			root.addElement(tiles.get(i));
		}
			
			root.addElement(player);
			
			
			// setup player speed
			float velocityX = 0f;
			float friction = 0.8f;
			
			// main loop
			while(true) {

				/* move player */
				if(EZInteraction.isKeyDown('a')) {
					velocityX -= 2f;
				}

				if(EZInteraction.isKeyDown('d')) {
					velocityX += 2f;
				}

				if(EZInteraction.isKeyDown('w')) {
					player.translateBy(0f, -4f);	
				}

				if(EZInteraction.isKeyDown('s')) {
					player.translateBy(0f, 4f);	
				}

				// apply friction
				velocityX *= friction;
				
				// move player
				player.translateBy(velocityX, 0);
				
				// NOTE: the other images don't move within the group
//				System.out.println(picture1.getXCenter());

				// keep the root group following the opposite of the character
				root.translateTo(-player.getXCenter() + 200f, 0);
				
				// update screen
				EZ.refreshScreen();

			}
	}
}
	
	
